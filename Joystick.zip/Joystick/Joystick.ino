#include "arduino_secrets.h"

JOYSTICK 
Joystick â 4 LEDs
-dimming when pushing

int X_PIN = A0;
int Y_PIN = A1;

int redLED = 3;
int yellowLED = 5;
int greenLED = 6;
int blueLED = 9;

void setup() {
  pinMode(X_PIN, INPUT);
  pinMode(Y_PIN, INPUT);

  pinMode(redLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
  pinMode(greenLED, OUTPUT);
  pinMode(blueLED, OUTPUT);

  Serial.begin(9600);
}

void loop() {
  int x = analogRead(X_PIN);
  int y = analogRead(Y_PIN);

  Serial.print("x = ");
  Serial.print(x);
  Serial.print(", y = ");
  Serial.println(y);
  delay(200);

  int right = 0;
  int left = 0;
  int up = 0;
  int down = 0;

  if (x > 512)
    left = map(x, 512, 1023, 0, 255);
  else
    right = map(x, 512, 0, 0, 255);

  if (y > 502)
    up = map(y, 502, 1023, 0, 255);
  else
    down = map(y, 502, 0, 0, 255);

  analogWrite(redLED, up);
  analogWrite(greenLED, down);
  analogWrite(yellowLED, left);
  analogWrite(blueLED, right);

  delay(10);
}
