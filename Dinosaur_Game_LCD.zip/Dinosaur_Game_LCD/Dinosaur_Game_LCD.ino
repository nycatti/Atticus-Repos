#include "arduino_secrets.h"

#include <DIYables_LCD_I2C.h>

DIYables_LCD_I2C lcd(0x27, 16, 2);

// ---------- Custom Characters ----------
byte customChar0[8] = { // Bird
  0b00000,
  0b01110,
  0b01110,
  0b11111,
  0b00100,
  0b00000,
  0b00000,
  0b00000
};

byte customChar1[8] = { // Cactus
  0b00000,
  0b10100,
  0b10100,
  0b11100,
  0b00101,
  0b00111,
  0b00100,
  0b00100
};

byte customChar2[8] = { // Dino
  0b00111,
  0b00111,
  0b00111,
  0b10100,
  0b11110,
  0b11110,
  0b11110,
  0b10010
};

// ---------- Pins ----------
int buttonPin = 2;
int HPLED1 = 4;
int HPLED2 = 5;
int HPLED3 = 6;
int buzzerPin = 9;
int potentPin = A0;

// ---------- Game Variables ----------
int dinoRow = 1;
int hp = 3;

struct Obstacle{
  int col;
  int row;
  byte type;
};

Obstacle obstacle;

unsigned long lastMove = 0;

bool lastButton = LOW;

// ---------- Functions ----------

void updateHP(){
  digitalWrite(HPLED1, hp >= 1);
  digitalWrite(HPLED2, hp >= 2);
  digitalWrite(HPLED3, hp >= 3);
}

void hitSound(){
  tone(buzzerPin,600,120);
  delay(130);
  tone(buzzerPin,350,150);
  delay(160);
}

void loseMusic(){

  int notes[]={
    523,494,440,392,
    349,330,294,262
  };

  for(int i=0;i<8;i++){
    tone(buzzerPin,notes[i],250);
    delay(280);
  }

  noTone(buzzerPin);
}

void newObstacle(){

  obstacle.col = 15;

  if(random(2)==0){
      obstacle.type = 0;      // bird
      obstacle.row = random(0,2);
  }
  else{
      obstacle.type = 1;      // cactus
      obstacle.row = 1;
  }
}

void resetGame(){

  hp = 3;
  updateHP();

  dinoRow = 1;

  lcd.clear();

  newObstacle();
}

void setup() {

  randomSeed(analogRead(A1));

  pinMode(buttonPin,INPUT);
  pinMode(potentPin,INPUT);

  pinMode(HPLED1,OUTPUT);
  pinMode(HPLED2,OUTPUT);
  pinMode(HPLED3,OUTPUT);

  pinMode(buzzerPin,OUTPUT);

  lcd.init();
  lcd.backlight();

  lcd.createChar(0,customChar0);
  lcd.createChar(1,customChar1);
  lcd.createChar(2,customChar2);

  resetGame();
}

void loop() {

  // ---------------- Potentiometer Speed ----------------

  int pot = analogRead(potentPin);

  if(pot < 20){
      return;            // pause game
  }

  int moveDelay = map(pot,20,1023,700,80);

  // ---------------- Button ----------------

  bool button = digitalRead(buttonPin);

  if(button && !lastButton){

      if(dinoRow==0)
        dinoRow=1;
      else
        dinoRow=0;

  }

  lastButton = button;

  // ---------------- Move Obstacles ----------------

  if(millis()-lastMove > moveDelay){

      lastMove = millis();

      obstacle.col--;

      // Collision

      if(obstacle.col==2 && obstacle.row==dinoRow){

          hp--;
          updateHP();

          hitSound();

          obstacle.col=-1;
      }

      if(obstacle.col<0){

          newObstacle();

      }

      // Draw Screen

      lcd.clear();

      lcd.setCursor(2,dinoRow);
      lcd.write(byte(2));

      if(obstacle.col>=0){
          lcd.setCursor(obstacle.col,obstacle.row);
          lcd.write(obstacle.type);
      }

      // Lose

      if(hp<=0){

          lcd.clear();

          lcd.setCursor(4,0);
          lcd.print("GAME");

          lcd.setCursor(4,1);
          lcd.print("OVER");

          loseMusic();

          delay(1000);

          resetGame();
      }
  }
}

