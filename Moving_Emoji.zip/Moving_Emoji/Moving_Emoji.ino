#include "arduino_secrets.h"

#include <DIYables_LCD_I2C.h>


DIYables_LCD_I2C lcd(0x27, 16, 2); // I2C address 0x27, 16 column and 2 rows



                                                                             
byte customChar0[8] = {
  0b01110,
  0b01110,
  0b01110,
  0b00100,
  0b11111,
  0b00100,
  0b01010,
  0b10001
};


byte customChar1[8] = {
  0b00000,
  0b01010,
  0b11111,
  0b11111,
  0b01110,
  0b00100,
  0b00000,
  0b00000
};


byte customChar2[8] = {
  0b01010,
  0b01010,
  0b01110,
  0b10001,
  0b11011,
  0b10001,
  0b10101,
  0b01110
};

int x_position = 1;
int y_position = 0;
int X_PIN = A0;
int Y_PIN = A1;


void setup()
{
  lcd.init(); // initialize the lcd
  lcd.backlight();


  lcd.createChar(0, customChar0); // create a new custom character (index 0)
  lcd.createChar(1, customChar1); // create a new custom character (index 1)
  lcd.createChar(2, customChar2); // create a new custom character (index 2)


  lcd.setCursor(0, 0); // move cursor to (0, 0)
  lcd.write((byte)0);  // print the custom char 0 at (2, 0)

  lcd.setCursor(16, 1); // move cursor to (16, 1)
  lcd.write((byte)2);  // print the custom char 2 at (6, 0)


  Serial.begin(9600);

}


void loop()
{
  int x = analogRead(X_PIN);
  int y = analogRead(Y_PIN);

  Serial.print("x = ");
  Serial.print(x);
  Serial.print(", y = ");
  Serial.println(y);
  delay(200);

  if (y > 520){
    y_position = y_position - 1;
  }
  
  if (y < 500){
    y_position = y_position + 1;
  }

  if (x < 500){
    x_position = x_position + 1;
  }

  if (x > 520){
    x_position = x_position - 1;
  }

  if(x_position > 16){
    x_position = 16;
  }

  if(x_position < 0){
    x_position = 0;
  }

  if(y_position > 1){
    y_position = 1;
  }

  if(y_position < 0){
    y_position = 0;
  }
  
  lcd.clear();
  lcd.setCursor(x_position, y_position); 
  lcd.write((byte)1);
  delay(10);
  
  

}


